import { Component, } from '@angular/core';
import { ProductosService } from '../productos.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent   {
  productos: any;
  constructor(private productosService: ProductosService) {
    this.productos = this.productosService.getAll();
    console.log(this.productos);
  }
  }
